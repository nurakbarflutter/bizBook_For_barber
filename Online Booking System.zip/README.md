
  # Online Booking System

  This is a code bundle for Online Booking System. The original project is available at https://www.figma.com/design/yyrfVmDc6wMp9PIpjptySV/Online-Booking-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  